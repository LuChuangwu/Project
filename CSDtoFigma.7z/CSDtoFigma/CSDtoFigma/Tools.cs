﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSDtoFigma
{
    public class Tools
    {
        public static string  GetNodeAttributeValue(XmlNode node,string AttributeName)
        {
            if (!string.IsNullOrEmpty(((XmlElement)node).GetAttribute(AttributeName)))
            {
                return ((XmlElement)node).GetAttribute(AttributeName);
            }
            return null;
        }
        public static bool GetXmlNodeValue(XmlNode node, string value)
        {
            if (string.IsNullOrEmpty(((XmlElement)node).GetAttribute(value))) return false;
            if (((XmlElement)node).GetAttribute(value) == "True" || ((XmlElement)node).GetAttribute(value) == "1")
            {
                return true;
            }
            return false;
        }
    }
}
