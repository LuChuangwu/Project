﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CSDtoFigma
{
    public class DecodeImage
    {
        public static string  DecodeImageToBase(string path)
        {
            FileStream fileStream = new FileStream(path, FileMode.Open);
            byte[] imgage_bty = new byte[fileStream.Length];
            fileStream.Read(imgage_bty,0, imgage_bty.Length);
            fileStream.Dispose();
            return Convert.ToBase64String(imgage_bty);
            

        }
        public static string DecodeImageToHash(string path)
        {
            SHA1 sHA1 = new SHA1Managed();

            var hashcode = sHA1.ComputeHash(new FileInfo(path).Open(FileMode.Open));
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < hashcode.Length; i++)
            {
                stringBuilder.Append(hashcode[i].ToString("X2").ToLower());
            }

            return stringBuilder.ToString();
        }
    }
}
