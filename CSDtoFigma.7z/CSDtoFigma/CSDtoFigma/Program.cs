﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSDtoFigma
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlDocumentTool xmlDocument;
            while (true)
            {
                xmlDocument = new XmlDocumentTool(Console.ReadLine());
                Console.WriteLine(xmlDocument.GetJsonContent());
            }
           
        }
    }
}
