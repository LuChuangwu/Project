﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSDtoFigma
{
    public class ButtonTxetInfo : BaseInfo
    {
        public string text;
        public float font_size;
        public ButtonTxetInfo(XmlNode node) : base(node)
        {
            type = "TEXT";
            text = Tools.GetNodeAttributeValue(node, "ButtonText");
            font_size = Convert.ToSingle(Tools.GetNodeAttributeValue(node, "FontSize"));
            ccolor = Vector4.GetValueByXmlNode(node.SelectSingleNode("TextColor"));
        }
    }
}
