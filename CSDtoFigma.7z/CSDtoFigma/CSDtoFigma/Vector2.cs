﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSDtoFigma
{
    public class Vector2
    {
        private float x;
        private float y;
        public Vector2(float x,float y)
        {
            this.x = x;
            this.y = y;
        }
        public Vector2()
        {
           
        }
        public float X { get => x; }
        public float Y { get => y; }
       
        public static Vector2 zero
        {
            get
            {
                return new Vector2(0, 0);
            }
        }
        public static Vector2 Subtract(Vector2 orgin,Vector2 target)
        {
            return new Vector2(orgin.x - target.x, orgin.y - target.y);
        }
        public static Vector2 Add(Vector2 orgin, Vector2 target)
        {
            return new Vector2(orgin.x + target.x, orgin.y + target.y);
        }
        public static Vector2 Mulitp(Vector2 orgin, Vector2 target)
        {
            return new Vector2(orgin.x * target.x, orgin.y * target.y);
        }
        public static Vector2 GetValueByXmlNode(XmlNode node)
        {

            if (node == null) return null;
            Vector2 value = Vector2.zero;
            if (node.Attributes.Count > 0)
            {
                foreach (XmlAttribute item in node.Attributes)
                {
                    if (item.Name.ToLower().Contains("x"))
                    {
                        value.x = Convert.ToSingle(item.Value);
                    }
                    else
                    {
                        value.y = Convert.ToSingle(item.Value);
                    }
                }
            }
            return value;

        }
    }
}
