﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Newtonsoft.Json;

namespace CSDtoFigma
{
    public class LayerInfo
    {
        public string LayerName;
        public Vector2 LayerSize;

        public LayerInfo(string layerName, Vector2 layerSize)
        {
            LayerName = layerName;
            LayerSize = layerSize;
        }
    }
    public class XmlDocumentTool
    {
        protected string  parent_floder;
        public List<BaseInfo> NodeInfoList = new List<BaseInfo>();
        public static Dictionary<string, object> Json_dir = new Dictionary<string, object>();

        public XmlDocumentTool(string path)
        {
            parent_floder = path.Substring(0, path.LastIndexOf('\\'));
            XmlDocument document = new XmlDocument();
            document.Load(path);
            XmlNode root = document.SelectSingleNode("GameFile/Content/Content/ObjectData");
            Json_dir.Add("LayerInfo", GetLayerInfo(root));
            Json_dir.Add("NodeInfo", GetAllChild(root.SelectSingleNode("Children").ChildNodes, NodeInfoList));
            

        }
        public List<BaseInfo> GetAllChild(XmlNodeList nodeList,List<BaseInfo> infoList)
        {
            foreach (XmlElement item in nodeList)
            {
                if (item.Name== "AbstractNodeData")
                {
                    switch (item.GetAttribute("ctype"))
                    {


                        case "PanelObjectData":
                        case "PageViewObjectData":
                        case "ScrollViewObjectData":
                        case "ListViewObjectData":
                            infoList.Add(new VesselInfo(item));
                            break;
                        case "ImageViewObjectData":
                        case "CheckBoxObjectData":
                        //case "ButtonObjectData":
                            infoList.Add(new ImageInfo(item, parent_floder));
                            break;
                        case "TextObjectData":
                            infoList.Add(new TextInfo(item));
                            break;
                        case "ButtonObjectData":
                            infoList.Add(new ImageInfo(item, parent_floder));
                            infoList.Add(new ButtonTxetInfo(item));
                            break;
                    }
                }
                if (item.SelectSingleNode("Children")!=null)
                {
                    GetAllChild(item.SelectSingleNode("Children").ChildNodes, infoList);
                }
            }
            return infoList;
        }
        public LayerInfo GetLayerInfo(XmlNode xml)
        {
            LayerInfo layerInfo = null;
            string name = ((XmlElement)xml).GetAttribute("Name");
            Vector2 size = Vector2.GetValueByXmlNode(xml.SelectSingleNode("Size"));
            layerInfo = new LayerInfo(name, size);
            return layerInfo;
        }
        public string GetJsonContent()
        {
            if (Json_dir.Count<=0)
            {
                return null;
            }
            var json = JsonConvert.SerializeObject(Json_dir, Newtonsoft.Json.Formatting.Indented);
            return json;
        }

    }
}
