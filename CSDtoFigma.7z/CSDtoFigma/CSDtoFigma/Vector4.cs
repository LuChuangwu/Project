﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSDtoFigma
{
    public class Vector4
    {
       public float a;
       public float r;
       public float g;
       public float b;

      

        public Vector4(float a, float r, float g, float b)
        {
            this.a = a;
            this.r = r;
            this.g = g;
            this.b = b;
        }

        public Vector4()
        {
        }

        public static Vector4 Black
        {
            get { return new Vector4(0, 0, 0, 0); }
        }
        public static Vector4 White
        {
            get { return new Vector4(255, 255, 255, 255); }
        }
        public static Vector4 GetValueByXmlNode(XmlNode node)
        {
            
            Vector4 color = new Vector4();
            if (node == null) return White;
            foreach (XmlAttribute item in node.Attributes)
            {
               // Console.WriteLine(color.GetType().GetField(item.Name.ToLower()).Name);
                color.GetType().GetField(item.Name.ToLower()).SetValue(color, Convert.ToSingle(item.Value));
            }
            return color;

        }
    }
}
