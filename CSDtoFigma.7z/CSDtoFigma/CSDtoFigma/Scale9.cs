﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSDtoFigma
{
    public class Scale9
    {
        public float top;
        public float bottom;
        public float right;
        public float left;

        public Scale9()
        {
        }

        public Scale9 (XmlNode node)
        {
            Vector2 size = Vector2.GetValueByXmlNode(node.SelectSingleNode("Size"));
            Vector2 scale_w_h = new Vector2(Convert.ToSingle(Tools.GetNodeAttributeValue(node, "Scale9Width")), Convert.ToSingle(Tools.GetNodeAttributeValue(node, "Scale9Height")));
            right = Convert.ToSingle(Tools.GetNodeAttributeValue(node, "Scale9OriginX"));
            bottom = Convert.ToSingle(Tools.GetNodeAttributeValue(node, "Scale9OriginY"));
            top = size.Y - (bottom + scale_w_h.Y);
            left = size.X - (right + scale_w_h.X);
            Console.WriteLine(Convert.ToSingle(Tools.GetNodeAttributeValue(node, "Scale9OriginX")));
        }

        public Scale9(float top, float bottom, float right, float left)
        {
            this.top = top;
            this.bottom = bottom;
            this.right = right;
            this.left = left;
        }

        public static Scale9 zero
        {
            get
            {
                return new Scale9(0, 0, 0, 0);
            }
        }
    }
}
