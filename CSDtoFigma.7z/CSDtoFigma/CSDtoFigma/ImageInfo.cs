﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSDtoFigma
{
    public class ImageInfo:BaseInfo
    {

        public Scale9 scale = new Scale9();
        public List<string> hash=new List<string>();
        public string parent_floder;
        public ImageInfo(XmlNode node,string path):base(node)
        {
            parent_floder = path;
            type = "IMAGE";
            ccolor = Vector4.GetValueByXmlNode(node.SelectSingleNode("CColor"));
            scale = new Scale9(node);
            foreach (XmlElement item in node.ChildNodes)
            {
                if (!string.IsNullOrEmpty(item.GetAttribute("Path")))
                {
                    string item_path = item.GetAttribute("Path");
                    string base64 = DecodeImage.DecodeImageToBase(path + "/" + item_path.Replace('/', '\\'));
                    hash.Add(base64);
                }
            }
          //  hash .Add( ((XmlElement)node.SelectSingleNode("FileData")).GetAttribute("Path"));
        }
    }
}
