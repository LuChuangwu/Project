﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSDtoFigma
{
    public class TextInfo : BaseInfo
    {
        public float lineSpace = 0;
        public float letterSpace=0;
        public float fontSize;
        public string text;
        public bool outline;
        public float outlineSize;
        public Vector4 outLineColor;
        public bool shadowEnabled;
        public Vector2 shadowOffset;
        public Vector4 shadowColor;
        public TextInfo(XmlNode node) : base(node)
        {
            type = "TEXT";
            letterSpace =Convert.ToSingle(Tools.GetNodeAttributeValue(node, "AdditionalKerning"));
            lineSpace = Convert.ToSingle(Tools.GetNodeAttributeValue(node, "LineSpacing"));
            fontSize = Convert.ToSingle(Tools.GetNodeAttributeValue(node, "FontSize"));
            text = Tools.GetNodeAttributeValue(node, "LabelText");
            outline = Tools.GetXmlNodeValue(node,"OutlineEnabled");
            outlineSize= Convert.ToSingle(Tools.GetNodeAttributeValue(node, "OutlineSize"));
            outLineColor = Vector4.GetValueByXmlNode(node.SelectSingleNode("OutlineColor"));
            shadowOffset = new Vector2(Convert.ToSingle(Tools.GetNodeAttributeValue(node, "ShadowOffsetX")), -Convert.ToSingle(Tools.GetNodeAttributeValue(node, "ShadowOffsetY")));

            shadowEnabled = Tools.GetXmlNodeValue(node, "ShadowEnabled");
            shadowColor = Vector4.GetValueByXmlNode(node.SelectSingleNode("ShadowColor"));
            ccolor = Vector4.GetValueByXmlNode(node.SelectSingleNode("CColor"));


        }
    }
}
