﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSDtoFigma
{
    public class VesselInfo:BaseInfo
    {
        public bool clip=false;
        public bool hashash=false;
        public VesselInfo(XmlNode node):base(node)
        {
            
            type = "FRAME";
            ccolor = Vector4.GetValueByXmlNode(node.SelectSingleNode("FirstColor"));
            hashash = Tools.GetXmlNodeValue(node, "ComboBoxIndex");
            clip = Tools.GetXmlNodeValue(node,"ClipAble");
           

        }
       
    }
   
}
