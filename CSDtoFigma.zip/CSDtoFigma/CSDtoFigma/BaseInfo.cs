﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CSDtoFigma
{
    public class BaseInfo
    {
        public string name;
        public string type;
        public Vector2 size;
        public Vector2 position;
        public Vector4 ccolor;

        public BaseInfo(XmlNode node)
        {
            XmlElement element = (XmlElement)node;
            this.name = element.GetAttribute("Name");
            Vector2 scale = Vector2.GetValueByXmlNode(element.SelectSingleNode("Scale"));
            this.size = Vector2.Mulitp(Vector2.GetValueByXmlNode(element.SelectSingleNode("Size")), scale);
            Vector2 anchorPoint = Vector2.GetValueByXmlNode(element.SelectSingleNode("AnchorPoint"));
            Vector2 parent_size = Vector2.GetValueByXmlNode(node.ParentNode.ParentNode.SelectSingleNode("Size"));
            Vector2 position = Vector2.GetValueByXmlNode(element.SelectSingleNode("Position"));
            this.position = new Vector2((int)(position.X - (size.X * anchorPoint.X)), (int)(parent_size.Y - position.Y) - (size.Y *(1-anchorPoint.Y)));

        }

    }
}
