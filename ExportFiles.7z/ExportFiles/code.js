// This plugin will open a window to prompt the user to enter a number, and
// it will then create that many rectangles on the screen.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// This file holds the main code for the plugins. It has access to the *document*.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (see documentation).
// This shows the HTML page in "ui.html".
var panel = ["ListViewObjectData", "ScrollViewObjectData", "PanelObjectData", "PageViewObjectData"];
var Vector2 = function (x, y) {
    this.x = x;
    this.y = y;
};
var Vector4 = function (a, r, g, b) {
    this.a = a;
    this.r = r;
    this.g = g;
    this.b = b;
};
var FileRes = function (file_type, Type, Path, Plist) {
    this.file_type = file_type;
    this.Type = Type;
    this.Path = Path;
    this.Plist = Plist;
};
var tag = 1;
figma.showUI(__html__);
figma.ui.resize(550, 550);
let file;
// Calls to "parent.postMessage" from within the HTML page will trigger this
// callback. The callback will be passed the "pluginMessage" property of the
// posted message.
let curren_frame_array = GetAllFrame();
let curren_frame_count = curren_frame_array.length;
postMessage("1001", curren_frame_array);
figma.ui.onmessage = msg => {
    switch (msg.type) {
        case "0001":
            file = msg.value;
            break;
        case "1001":
            SendAllFrame();
            break;
        case "1005":
            GetChild(figma.currentPage.selection[0]);
            break;
        case "1003":
            if (figma.currentPage.selection[0] == null) {
                return;
            }
            SetCtypeAndActionTag(msg.value);
            break;
        case "1002":
            if (figma.currentPage.selection[0] == null) {
                return;
            }
            if (msg.value == "") {
                var node = null;
                if (figma.currentPage.selection[0].type == "INSTANCE") {
                    node = figma.currentPage.selection[0].mainComponent.parent;
                }
                else {
                    node = figma.currentPage.selection[0];
                }
                if (node != null) {
                    SendAllImage(node);
                }
            }
            else {
                SetImagData(msg.value);
            }
            break;
    }
};
function SetCtypeAndActionTag(obj) {
    if (figma.currentPage.selection[0] == null) {
        return;
    }
    var array = GetAllKeys(obj);
    for (var temp of array) {
        figma.currentPage.selection[0].setSharedPluginData("csd", temp, obj[temp].toString());
    }
}
function SetImagData(obj) {
    var array = GetAllKeys(obj);
    for (var temp of array) {
        var value;
        console.log(obj[temp]);
        if (obj[temp].split(":")[0] == "base64") {
            var image = figma.createImage(figma.base64Decode(obj[temp].toString().split(":")[1]));
            value = image.hash;
        }
        else {
            value = obj[temp].split(":")[1];
        }
        figma.currentPage.selection[0].setSharedPluginData("csd", temp, file[value]);
    }
}
function GetAllFrame() {
    let name_array = new Array();
    let count = 0;
    let fram_array = figma.currentPage.findAllWithCriteria({ types: ["GROUP", "FRAME"] });
    for (var node of fram_array) {
        name_array[count] = node.name;
        count += 1;
    }
    return name_array;
}
function FrameNameCheck(new_array, curren_frame_array) {
    for (var name of new_array) {
        if (curren_frame_array.indexOf(name) == -1) {
            return false;
        }
    }
    return true;
}
function SendAllFrame() {
    let now_array = GetAllFrame();
    if (now_array.length != curren_frame_count || FrameNameCheck(now_array, curren_frame_array) == false) {
        postMessage("1001", now_array);
        curren_frame_array = now_array;
        curren_frame_count = now_array.length;
    }
}
function SendAllImage(Node) {
    return __awaiter(this, void 0, void 0, function* () {
        if (Node == null) {
            return;
        }
        if ("fills" in Node) {
            for (let patin of Node.fills) {
                if (patin.type == "IMAGE") {
                    let image = figma.getImageByHash(patin.imageHash);
                    let byte = figma.base64Encode(yield image.getBytesAsync());
                    postMessage("1002", byte + "[" + patin.imageHash + ']');
                }
            }
        }
        if ("children" in Node) {
            if (Node.children.length > 0) {
                for (let child_node of Node.children) {
                    SendAllImage(child_node);
                }
            }
        }
    });
}
function GetAllKeys(obj) {
    var keys_array = Object.keys(obj);
    return keys_array;
}
function GetChild(Node) {
    var child_value = "";
    if ("children" in Node) {
        var children = Node.children;
        if (children.length > 0) {
            child_value = "<Children>\n";
            for (var i = 0; i < children.length; i++) {
                if (children[i].getSharedPluginData("csd", "ctype") != "") {
                    child_value += GetNodeProprty(children[i]);
                }
            }
            child_value += "\n</Children>";
        }
    }
    if (child_value == "<Children>\n" + "\n</Children>") {
        child_value = "";
    }
    console.log(child_value);
    return child_value;
}
function GetNodeProprty(Node) {
    var ctype = GetSharedPluginData(Node, "ctype");
    if (ctype != "") {
        tag += 1;
        switch (ctype) {
            case "PanelObjectData":
                return CreatCsdNode(new PanelObjectData(Node));
            case "ListViewObjectData":
                return CreatCsdNode(new ListViewObjectData(Node));
            case "PageViewObjectData":
                return CreatCsdNode(new PageViewObjectData(Node));
            case "ScrollViewObjectData":
                return CreatCsdNode(new ScrollViewObjectData(Node));
            case "ImageViewObjectData":
                return CreatCsdNode(new ImageViewObjectData(Node));
            case "ButtonObjectData":
                return CreatCsdNode(new ButtonObjectData(Node));
            case "LoadingBarObjectData":
                return CreatCsdNode(new LoadingBarObjectData(Node));
            case "SliderObjectData":
                return CreatCsdNode(new SliderObjectData(Node));
            case "TextObjectData":
                return CreatCsdNode(new TextObjectData(Node));
        }
    }
}
var BaseInfo = function (node) {
    this.head =
        {};
    this.body = {};
    var parent_size_width = Number(GetSharedPluginData(node.parent, "width")) > node.parent.width ? Number(GetSharedPluginData(node.parent, "width")) : node.parent.width;
    var parent_size_height = Number(GetSharedPluginData(node.parent, "height")) > node.parent.height ? Number(GetSharedPluginData(node.parent, "height")) : node.parent.height;
    this.parent = node.parent.name;
    //Tag
    this.head.Tag = 'Tag="' + tag + '"';
    //Name
    this.head.Name = 'Name="' + node.name + '"';
    //ctype
    this.head.ctype = 'ctype="' + GetSharedPluginData(node, "ctype") + '"';
    //actiontag
    this.head.AnctionTag = 'ActionTag="' + GetSharedPluginData(node, "ActionTag") + '"';
    //size
    var size_value = new Vector2(node.width, node.height);
    ;
    this.inner_size = new Vector2(0, 0);
    if ("children" in node) {
        if (node.children.length > 0) {
            var last_node = node.children[0];
            var last_node_x = last_node.x + last_node.width;
            var last_node_y = last_node.y + last_node.height;
            for (var i = 0; i < node.children.length; i++) {
                var curren_x = node.children[i].x + node.children[i].width;
                var curren_y = node.children[i].y + node.children[i].height;
                if (last_node_x < curren_x) {
                    this.inner_size.x = curren_x;
                }
                if (last_node_y < curren_y) {
                    this.inner_size.y = curren_y;
                }
            }
        }
    }
    this.body.Size = '<Size X="' + size_value.x.toFixed(4) + '" Y="' + size_value.y.toFixed(4) + '" />';
    SetSharedPluginData(node, "width", this.inner_size.x.toString());
    SetSharedPluginData(node, "height", this.inner_size.y.toString());
    //Children need do
    if ("children" in node) {
        if (node.children.length > 0) {
            this.body.Children = GetChild(node);
        }
    }
    //anchorpoint
    var anchorpoint_value = GetAnchorPoint(GetSharedPluginData(node, "AnchorPoint"));
    this.body.AnchorPoint = '<AnchorPoint ScaleX="' + anchorpoint_value.x + '" ScaleY="' + anchorpoint_value.y + '" />';
    //positon
    var x = 0;
    var y = 0;
    if (node.parent.type != "GROUP") {
        x = node.x + (node.width * Number(anchorpoint_value.x));
        y = parent_size_height - node.y - (node.height * (1 - Number(anchorpoint_value.y)));
    }
    else {
        x = (node.x - node.parent.x) + (node.width * Number(anchorpoint_value.x));
        y = node.parent.height - ((node.y - node.parent.y) + (node.height * Number(anchorpoint_value.y)));
    }
    this.body.Position = '<Position X="' + x.toFixed(4) + '" Y="' + y.toFixed(4) + '" />';
    //pre_size
    var pre_size_x = (size_value.x / parent_size_width).toFixed(4);
    var pre_size_y = (size_value.y / parent_size_height).toFixed(4);
    this.body.PreSize = '<PreSize X="' + pre_size_x + '" Y="' + pre_size_y + '" />';
    //pre_position
    var pre_position_x = x / parent_size_width;
    var pre_position_y = y / parent_size_height;
    this.body.PrePosition = '<PrePosition X="' + pre_position_x.toFixed(4) + '" Y="' + pre_position_y.toFixed(4) + '" />';
    //ccolor
    this.body.CColor = '<SingleColor A="' + 255 + '" R="' + 255 + '" G="' + 255 + '" B="' + 255 + '" />';
    //Marigin
    this.head.BottomMargin = 'BottomMargin="' + y.toFixed(4) + '"';
    this.head.RightMargin = 'RightMargin="' + x.toFixed(4) + '"';
    this.head.LeftMargin = 'LeftMargin="' + (node.parent.width - (x + node.width)).toFixed(4) + '"';
    this.head.TopMargin = 'TopMargin="' + (node.parent.height - (y + node.height)).toFixed(4) + '"';
    this.head.TouchEnable = "";
    //IconVisible
    this.head.IconVisible = 'IconVisible="False"';
    this.body.Scale = '<Scale ScaleX="1.0000" ScaleY="1.0000" />';
};
var PanelObjectData = function (node) {
    this.baseInfo = new BaseInfo(node);
    this.fill =
        {
            color: new Vector4(1, 1, 1, 1),
            opacity: 1
        };
    if ("fills" in node) {
        if (node.type != "GROUP" && node.fills.length > 0) {
            if (node.fills[0].type == "SOLID") {
                this.fill = node.fills[0];
            }
        }
    }
    //BackColorAlpha
    var backalpha = 102;
    backalpha = this.fill.opacity * 255;
    this.baseInfo.head.BackColorAlpha = 'BackColorAlpha="' + backalpha + '"';
    //ClipAble
    if ("clipsContent" in node) {
        this.baseInfo.head.ClipAble = 'ClipAble="' + node.clipsContent + '"';
    }
    else {
        this.baseInfo.head.ClipAble = '';
    }
    //ComboBoxIndex
    var comboBoxIndex = "";
    if (this.fill.type == "SOLID") {
        comboBoxIndex = 'ComboBoxIndex="' + 1 + '"';
    }
    this.baseInfo.head.ComboBoxIndex = comboBoxIndex;
    //SingleColor
    this.baseInfo.body.SingleColor = '<SingleColor A="' + 255 + '" R="' + (this.fill.color.r * 255).toFixed(0) + '" G="' + (this.fill.color.g * 255).toFixed(0) + '" B="' + (this.fill.color.b * 255).toFixed(0) + '" />';
    this.baseInfo.body.FirstColor = '<FirstColor A="' + 255 + '" R="' + (this.fill.color.r * 255).toFixed(0) + '" G="' + (this.fill.color.g * 255).toFixed(0) + '" B="' + (this.fill.color.b * 255).toFixed(0) + '" />';
    this.baseInfo.body.EndColor = '<EndColor A="' + 255 + '" R="' + 255 + '" G="' + 255 + '" B="' + 255 + '" />';
    this.baseInfo.body.ColorVector = '<ColorVector ScaleY="1.0000" />';
    this.baseInfo.head.Scale9Height = 'Scale9Height="' + 1 + '"';
    this.baseInfo.head.Scale9Width = 'Scale9Width="' + 1 + '"';
    //ColorAngel
    this.baseInfo.head.ColorAngle = 'ColorAngle="90.0000"';
};
var ListViewObjectData = function (node) {
    this.baseInfo = new PanelObjectData(node).baseInfo;
    //滚动方向
    this.baseInfo.head.DirectionType = "";
    this.baseInfo.head.ScrollDirectionType = 'ScrollDirectionType="0"';
    this.baseInfo.head.LayoutType = 'LayoutType="2"';
    if (this.baseInfo.inner_size.y + this.baseInfo.inner_size.width > node.height) {
        this.baseInfo.head.DirectionType = 'DirectionType="Vertical"';
        this.baseInfo.head.LayoutType = 'LayoutType="1"';
    }
    if ("layoutMode" in node) {
        if (node.layoutMode == "VERTICAL") {
            this.baseInfo.head.DirectionType = 'DirectionType="Vertical"';
            this.baseInfo.head.LayoutType = 'LayoutType="1"';
        }
    }
    //子控件间距
    this.baseInfo.head.ItemMargin = "";
    if ("layoutMode" in node) {
        this.baseInfo.head.ItemMargin = 'ItemMargin="' + node.itemSpacing + '"';
    }
    else {
        var item_space;
        if (node.layoutMode == "VERTICAL") {
            item_space = node.children[1].y - (node.children[0].y + node.children[0].height);
        }
        else {
            item_space = node.children[1].x - (node.children[0].x + node.children[0].width);
        }
        this.baseInfo.head.ItemMargin = 'ItemMargin="' + item_space + '"';
    }
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
    //console.warn(this.baseInfo);
};
var PageViewObjectData = function (Node) {
    var Frame = figma.createFrame();
    Frame.x = Node.x;
    Frame.y = Node.y;
    Frame.resize(Node.width, Node.height);
    Frame.name = Node.name;
    Node.parent.appendChild(Frame);
    SetSharedPluginData(Frame, "ctype", "PageViewObjectData");
    SetSharedPluginData(Frame, "ActionTag", GetActionTag(9));
    SetSharedPluginData(Frame, "AnchorPoint", "0.0000,0.0000");
    SetSharedPluginData(Node, "ctype", "PanelObjectData");
    SetSharedPluginData(Frame, "ActionTag", GetActionTag(9));
    Node.x = Node.x - Frame.x;
    Node.y = Node.y - Frame.y;
    Frame.appendChild(Node);
    this.baseInfo = new ListViewObjectData(Frame).baseInfo;
    this.baseInfo.head.ItemMargin = "";
    this.baseInfo.head.DirectionType = "";
    this.baseInfo.head.LayoutType = 'LayoutType="2"';
};
var ScrollViewObjectData = function (Node) {
    this.baseInfo = new ListViewObjectData(Node).baseInfo;
    this.baseInfo.head.LayoutType = '';
    this.baseInfo.head.ScrollDirectionType = 'ScrollDirectionType="Vertical"';
    if (this.baseInfo.inner_size.x > Node.width) {
        this.baseInfo.head.ScrollDirectionType = 'ScrollDirectionType="Horizontal"';
    }
    if (this.baseInfo.inner_size.y > Node.height && this.baseInfo.inner_size.x > Node.width) {
        this.baseInfo.head.ScrollDirectionType = 'ScrollDirectionType="Vertical_Horizontal"';
    }
    var inner_x = this.baseInfo.inner_size.x > Node.width ? this.baseInfo.inner_size.x : Node.width;
    var inner_y = this.baseInfo.inner_size.y > Node.height ? this.baseInfo.inner_size.y : Node.height;
    this.baseInfo.body.InnerNodeSize = '<InnerNodeSize Width="' + inner_x + '" Height="' + inner_y + '" />';
};
var ImageViewObjectData = function (Node) {
    this.baseInfo = new BaseInfo(Node);
    if ("fills" in Node && Node.fills.length > 0) {
        console.log(Node.fills[0].opacity * 255);
        this.baseInfo.head.Alpha = 'Alpha="' + (Node.fills[0].opacity * 255).toFixed(0) + '"';
    }
    this.baseInfo.body.path = '<FileData Type="Default" Path="Default/ImageFile.png" Plist="" />';
    if (GetSharedPluginData(Node, "FileData") != null) {
        this.baseInfo.body.path = '<FileData Type="Normal" Path="' + GetSharedPluginData(Node, "FileData") + '" Plist="" />';
    }
};
var LoadingBarObjectData = function (Node) {
    this.baseInfo = new ImageViewObjectData(Node).baseInfo;
    this.baseInfo.body.path = '<ImageFileData Type="Default" Path="Default/ImageFile.png" Plist="" />';
    if (GetSharedPluginData(Node, "FileData") != null) {
        this.baseInfo.body.path = '<ImageFileData Type="Normal" Path="' + GetSharedPluginData(Node, "ImageFileData") + '" Plist="" />';
    }
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
};
var ButtonObjectData = function (Node) {
    this.baseInfo = new BaseInfo(Node);
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
    this.baseInfo.head.FontSiz = 'FontSize="14"';
    var BottomEage = 14;
    var LeftEage = 15;
    var RightEage = 15;
    var TopEage = 14;
    var Scale9Width = Node.width - (RightEage + LeftEage);
    var Scale9Height = Node.width - (BottomEage + TopEage);
    var Scale9OriginX = LeftEage;
    var Scale9OriginY = BottomEage;
    this.baseInfo.head.Scale9Width = 'Scale9Width="' + Scale9Width + '"';
    this.baseInfo.head.Scale9Height = 'Scale9Height="' + Scale9Height + '"';
    this.baseInfo.head.Scale9OriginX = 'Scale9OriginX="' + Scale9OriginX + '"';
    this.baseInfo.head.Scale9OriginY = 'Scale9OriginY="' + Scale9OriginY + '"';
    this.baseInfo.head.BottomEage = 'BottomEage="' + BottomEage + '"';
    this.baseInfo.head.LeftEage = 'LeftEage="' + LeftEage + '"';
    this.baseInfo.head.RightEage = 'RightEage="' + RightEage + '"';
    this.baseInfo.head.TopEage = 'TopEage="' + TopEage + '"';
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
    this.baseInfo.head.ShadowOffsetX = 'ShadowOffsetX="2.0000"';
    this.baseInfo.head.ShadowOffsetY = 'ShadowOffsetY="2.0000"';
    this.baseInfo.body.TextColor = '<TextColor A="255" R="65" G="65" B="70" />';
    this.baseInfo.body.DisabledFileData = '<DisabledFileData Type="Default" Path="Default/Button_Disable.png" Plist="" />';
    this.baseInfo.body.PressedFileData = '<PressedFileData Type="Default" Path="Default/Button_Press.png" Plist="" />';
    this.baseInfo.body.NormalFileData = '<NormalFileData Type="Default" Path="Default/Button_Normal.png" Plist="" />';
    if (GetSharedPluginData(Node, "DisabledFileData") != null) {
        this.baseInfo.body.DisabledFileData = '<DisabledFileData Type="Normal" Path="' + GetSharedPluginData(Node, "DisabledFileData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "PressedFileData") != null) {
        this.baseInfo.body.PressedFileData = '<PressedFileData Type="Normal" Path="' + GetSharedPluginData(Node, "PressedFileData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "NormalFileData") != null) {
        this.baseInfo.body.NormalFileData = '<NormalFileData Type="Normal" Path="' + GetSharedPluginData(Node, "NormalFileData") + '" Plist="" />';
    }
};
var SliderObjectData = function (Node) {
    this.baseInfo = new BaseInfo(Node);
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
    this.baseInfo.head.PercentInfo = 'PercentInfo="50"';
    this.baseInfo.body.BackGroundData = '<BackGroundData Type="Default" Path="Default/Slider_Back.png" Plist="" />';
    this.baseInfo.body.ProgressBarData = '<ProgressBarData Type="Default" Path="Default/Slider_PressBar.png" Plist="" />';
    this.baseInfo.body.BallNormalData = '<BallNormalData Type="Default" Path="Default/SliderNode_Normal.png" Plist="" />';
    if (GetSharedPluginData(Node, "BackGroundData") != null) {
        this.baseInfo.body.BackGroundData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "BackGroundData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "ProgressBarData") != null) {
        this.baseInfo.body.ProgressBarData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "ProgressBarData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "BallNormalData") != null) {
        this.baseInfo.body.BallNormalData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "BallNormalData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "BallPressedData") != null) {
        this.baseInfo.body.BallPressedData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "BallPressedData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "BallDisabledData") != null) {
        this.baseInfo.body.BallDisabledData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "BallDisabledData") + '" Plist="" />';
    }
};
var TextObjectData = function (Node) {
    if (Node.type != "TEXT") {
        return;
    }
    ;
    figma.loadFontAsync(Node.fontName);
    this.baseInfo = new BaseInfo(Node);
    this.baseInfo.head.FontSize = 'FontSize="' + Node.fontSize + '"';
    this.baseInfo.head.AdditionalKerning = 'AdditionalKerning="' + Node.letterSpacing.value + '"';
    this.baseInfo.head.LabelText = 'LabelText="' + Node.characters + '"';
    if (Node.lineHeight.value != undefined) {
        this.baseInfo.head.LineSpacing = 'LineSpacing="' + Node.lineHeight.value + '"';
    }
    this.baseInfo.body.OutlineColor = '<OutlineColor A="255" R="255" G="0" B="0" />';
    this.baseInfo.head.ShadowOffsetX = 'ShadowOffsetX="2.0000"';
    this.baseInfo.head.ShadowOffsetY = 'ShadowOffsetY="2.0000"';
    if ("strokes" in Node && Node.strokes.length > 0) {
        var color = Node.strokes[0].color;
        this.baseInfo.head.OutlineEnabled = 'OutlineEnabled="True"';
        this.baseInfo.body.OutlineColor = '<OutlineColor A="255" R="' + (color.r * 255).toFixed(0) + '" G="' + (color.g * 255).toFixed(0) + '" B="' + (color.b * 255).toFixed(0) + '" />';
        this.baseInfo.head.OutlineSize = 'OutlineSize="' + Node.strokeWeight + '"';
    }
    if ("effects" in Node && Node.effects.length > 0) {
        var color = Node.effects[0].color;
        this.baseInfo.head.ShadowEnabled = 'ShadowEnabled="True"';
        this.baseInfo.body.ShadowColor = '<ShadowColor A="' + (color.a * 255).toFixed(0) + '" R="' + (color.r * 255).toFixed(0) + '" G="' + (color.g * 255).toFixed(0) + '" B="' + (color.b * 255).toFixed(0) + '" />';
        this.baseInfo.head.ShadowOffsetX = 'ShadowOffsetX="' + (Node.effects[0].offset.x).toFixed(4) + '"';
        this.baseInfo.head.ShadowOffsetY = 'ShadowOffsetY="' + (-Node.effects[0].offset.y).toFixed(4) + '"';
    }
    if ("fills" in Node && Node.fills.length > 0) {
        var color = Node.fills[0].color;
        this.baseInfo.body.CColor = '<CColor A="255" R="' + (color.r * 255).toFixed(0) + '" G="' + (color.g * 255).toFixed(0) + '" B="' + (color.b * 255).toFixed(0) + '" />';
    }
};
function GetAnchorPoint(value) {
    var x = value.split(',')[0];
    var y = value.split(',')[0];
    var anchorPoint = new Vector2(x, y);
    return anchorPoint;
}
function postMessage(_type, value) {
    figma.ui.postMessage(_type + ":" + value);
}
function GetSharedPluginData(Node, key) {
    return Node.getSharedPluginData("csd", key);
}
function SetSharedPluginData(Node, key, value) {
    Node.setSharedPluginData("csd", key, value);
}
function CreatCsdNode(info) {
    var head_keys = Object.keys(info.baseInfo.head);
    var content = '<AbstractNodeData';
    for (var key in head_keys) {
        content += ' ' + info.baseInfo.head[head_keys[key]];
    }
    content += '>';
    var body_keys = Object.keys(info.baseInfo.body);
    for (var key in body_keys) {
        content += '\n' + info.baseInfo.body[body_keys[key]];
    }
    content += '\n</AbstractNodeData>\n';
    return content;
}
function GetActionTag(count) {
    var action_tag = "";
    for (let index = 0; index < count; index++) {
        action_tag += Math.floor(Math.random() * 10);
    }
    return action_tag;
}
