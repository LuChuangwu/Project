// This plugin will open a window to prompt the user to enter a number, and
// it will then create that many rectangles on the screen.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// This file holds the main code for the plugins. It has access to the *document*.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (see documentation).
// This shows the HTML page in "ui.html".
var Vector2 = function (x, y) {
    this.x = x;
    this.y = y;
};
var Vector4 = function (x, y, z, t) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.t = t;
};
var FileRes = function (file_type, Type, Path, Plist) {
    this.file_type = file_type;
    this.Type = Type;
    this.Path = Path;
    this.Plist = Plist;
};
figma.showUI(__html__);
figma.ui.resize(550, 550);
let file;
// Calls to "parent.postMessage" from within the HTML page will trigger this
// callback. The callback will be passed the "pluginMessage" property of the
// posted message.
let curren_frame_array = GetAllFrame();
let curren_frame_count = curren_frame_array.length;
postMessage("1001", curren_frame_array);
figma.ui.onmessage = msg => {
    switch (msg.type) {
        case "0001":
            file = msg.value;
            break;
        case "1001":
            SendAllFrame();
            break;
        case "1005":
            GetChild(figma.currentPage.selection[0]);
            break;
        case "1003":
            if (figma.currentPage.selection[0] == null) {
                return;
            }
            SetCtypeAndActionTag(msg.value);
            break;
        case "1002":
            if (figma.currentPage.selection[0] == null) {
                return;
            }
            if (msg.value == "") {
                var node = null;
                if (figma.currentPage.selection[0].type == "INSTANCE") {
                    node = figma.currentPage.selection[0].mainComponent.parent;
                }
                else {
                    node = figma.currentPage.selection[0];
                }
                if (node != null) {
                    SendAllImage(node);
                }
            }
            else {
                SetImagData(msg.value);
            }
            break;
    }
};
function SetCtypeAndActionTag(obj) {
    if (figma.currentPage.selection[0] == null) {
        return;
    }
    var array = GetAllKeys(obj);
    for (var temp of array) {
        figma.currentPage.selection[0].setSharedPluginData("csd", temp, obj[temp].toString());
    }
}
function SetImagData(obj) {
    var array = GetAllKeys(obj);
    for (var temp of array) {
        var value;
        if (obj[temp].split(":")[0] == "base64") {
            var image = figma.createImage(figma.base64Decode(obj[temp].toString().split(":")[1]));
            value = image.hash;
        }
        else {
            value = obj[temp].split(":")[1];
        }
        // console.log(file["f48c99c2c0dcabd40a080f3e544eef5be4eb1091"]);
        figma.currentPage.selection[0].setSharedPluginData("csd", temp, file[value]);
    }
}
function GetAllFrame() {
    let name_array = new Array();
    let count = 0;
    let fram_array = figma.currentPage.findAllWithCriteria({ types: ["GROUP", "FRAME"] });
    for (var node of fram_array) {
        name_array[count] = node.name;
        count += 1;
    }
    return name_array;
}
function FrameNameCheck(new_array, curren_frame_array) {
    for (var name of new_array) {
        if (curren_frame_array.indexOf(name) == -1) {
            return false;
        }
    }
    return true;
}
function SendAllFrame() {
    let now_array = GetAllFrame();
    if (now_array.length != curren_frame_count || FrameNameCheck(now_array, curren_frame_array) == false) {
        postMessage("1001", now_array);
        curren_frame_array = now_array;
        curren_frame_count = now_array.length;
    }
}
function SendAllImage(Node) {
    return __awaiter(this, void 0, void 0, function* () {
        if (Node == null) {
            return;
        }
        if ("fills" in Node) {
            for (let patin of Node.fills) {
                if (patin.type == "IMAGE") {
                    let image = figma.getImageByHash(patin.imageHash);
                    let byte = figma.base64Encode(yield image.getBytesAsync());
                    postMessage("1002", byte + "[" + patin.imageHash + ']');
                }
            }
        }
        if ("children" in Node) {
            if (Node.children.length > 0) {
                for (let child_node of Node.children) {
                    SendAllImage(child_node);
                }
            }
        }
    });
}
function GetAllKeys(obj) {
    var keys_array = Object.keys(obj);
    return keys_array;
}
function GetChild(Node) {
    var child_value = "";
    if ("children" in Node) {
        var children = Node.children;
        if (children.length > 0) {
            child_value = "<Children>\n";
            for (var i = 0; i < children.length; i++) {
                if (children[i].getSharedPluginData("csd", "ctype") != "") {
                    console.log(children[i].getSharedPluginData("csd", "ctype"));
                }
                CreateNode(children[i]);
            }
            child_value += "</Children>\n";
        }
    }
    return child_value;
}
function CreateNode(Node) {
    GetChild(Node);
}
function GetNodeProprty(Node) {
    var property = {
        AnchorPoint: Vector2,
        Size: Vector2,
        Position: Vector2,
        Scale: Vector2,
        CColor: Vector4,
        PrePosition: Vector2,
        PreSize: Vector2,
        SingleColor: Vector4,
        FirstColor: Vector4,
        EndColor: Vector4,
        InnerNodeSize: Vector2,
        TextColor: Vector4,
        OutlineColor: Vector4,
        ShadowColor: Vector4,
        ButtonObjectData: {
            DisabledFileData: FileRes,
            PressedFileData: FileRes,
            NormalFileData: FileRes,
        },
        CheckBoxObjectData: {
            NormalBackFileData: FileRes,
            PressedBackFileData: FileRes,
            DisableBackFileData: FileRes,
            NodeNormalFileData: FileRes,
            NodeDisableFileData: FileRes,
        },
        ImageViewObjectData: {
            FileData: FileRes
        },
        LoadingBarObjectData: {
            ImageFileData: FileRes
        },
        SliderObjectData: {
            BackGroundData: FileRes,
            ProgressBarData: FileRes,
            BallNormalData: FileRes,
            BallPressedData: FileRes,
            BallDisabledData: FileRes,
        },
        Name: "",
        ctype: "",
        ActionTag: "",
        margin: {
            top: "",
            left: "",
            right: "",
            bottom: ""
        },
        TouchEnable: Boolean,
        Tag: Number,
        IconVisible: Boolean,
        ProgressInfo: Number,
        CheckedState: Boolean,
        Scale9: Vector2,
        Eage: Vector4,
        FontSize: Number,
        ButtonText: "",
        Scale9Origin: Vector2,
        BackColorAlpha: Number,
        ClipAble: Boolean,
        ColorAngle: "90.0000",
        DirectionType: "",
        ScrollDirectionType: Number,
        ComboBoxIndex: Number,
        LayoutType: Number(),
    };
    //锚点
    property.AnchorPoint = new Vector2(GetSharedPluginData(Node, "AnchorPoint").split(',')[0], GetSharedPluginData(Node, "AnchorPoint").split(',')[1]);
    //property.AnchorPoint.y=
    //尺寸
    property.Size = new Vector2(Node.width, Node.height);
    //位置
    property.Position = ChangePosition(Node, property.AnchorPoint);
    return property;
}
function ChangePosition(Node, AnchorPoint) {
    let x;
    let y;
    if (Node.parent.type == "FRAME" || Node.parent.type == "INSTANCE") {
        x = (Node.x + Node.width * AnchorPoint.x).toFixed(4);
        y = (Node.parent.y - (Node.y + Node.height * (1 - AnchorPoint.y))).toFixed(4);
    }
    // if(Node.parent.type=="GROUP")
    // {
    //  x=((Node.x-Node.parent.x)+Node.width*AnchorPoint.x).toFixed(4);
    //  y=(Node.parent.y-((Node.y-Node.parent.y)+property.tempsize.y*(1-property.anchorPoint.scaleY))).toFixed(4);
    // }
    return new Vector2(x, y);
}
function postMessage(_type, value) {
    figma.ui.postMessage(_type + ":" + value);
}
function GetSharedPluginData(Node, key) {
    return Node.getSharedPluginData("csd", key);
}
function SetSharedPluginData(Node, key, value) {
    Node.settSharedPluginData("csd", key, value);
}
