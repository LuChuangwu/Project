// This plugin will open a window to prompt the user to enter a number, and
// it will then create that many rectangles on the screen.
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// This file holds the main code for the plugins. It has access to the *document*.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (see documentation).
// This shows the HTML page in "ui.html".
var panel = ["ListViewObjectData", "ScrollViewObjectData", "PanelObjectData", "PageViewObjectData"];
var Vector2 = function (x, y) {
    this.x = x;
    this.y = y;
};
var Vector4 = function (a, r, g, b) {
    this.a = a;
    this.r = r;
    this.g = g;
    this.b = b;
};
var FileRes = function (file_type, Type, Path, Plist) {
    this.file_type = file_type;
    this.Type = Type;
    this.Path = Path;
    this.Plist = Plist;
};
var tag = 1;
figma.showUI(__html__);
figma.ui.resize(540, 400);
let file = null;
;
// Calls to "parent.postMessage" from within the HTML page will trigger this
// callback. The callback will be passed the "pluginMessage" property of the
// posted message.
let curren_frame_array = GetAllFrame();
let curren_frame_count = curren_frame_array.length;
postMessage("1001", curren_frame_array);
figma.on("selectionchange", () => {
    if (figma.currentPage.selection[0] != null) {
        postMessage("1006", GetSharedPluginData(figma.currentPage.selection[0], "ctype"));
    }
});
figma.ui.onmessage = msg => {
    switch (msg.type) {
        case "0001":
            file = msg.value;
            if (file != null) {
                figma.notify("file loaded");
            }
            break;
        case "1001":
            SendAllFrame();
            break;
        case "1000":
            if (figma.currentPage.selection[0] != null) {
                postMessage("1000", true);
            }
            else {
                postMessage("1000", false);
            }
            break;
        case "1005":
            if (figma.currentPage.selection[0] == null) {
                figma.notify("请选择一个画布导出");
                return;
            }
            var size = new Vector2(figma.currentPage.selection[0].width, figma.currentPage.selection[0].height);
            var value = {
                csd_content: GetChild(figma.currentPage.selection[0]),
                layer_size: size
            };
            postMessage("1005", value);
            break;
        case "1003":
            if (figma.currentPage.selection[0] == null) {
                return;
            }
            SetCtypeAndActionTag(msg.value);
            break;
        case "1002":
            if (figma.currentPage.selection[0] == null) {
                return;
            }
            if (msg.value == "") {
                var node = null;
                if (figma.currentPage.selection[0].type == "INSTANCE" && figma.currentPage.selection[0].mainComponent.parent != null) {
                    node = figma.currentPage.selection[0].mainComponent.parent;
                }
                else {
                    node = figma.currentPage.selection[0];
                }
                if (node != null) {
                    SendAllImage(node);
                }
            }
            else {
                SetImagData(msg.value);
            }
            break;
        case "1007":
            ClearSharedPlugingData(figma.currentPage.selection[0]);
            break;
        case "resize":
            figma.ui.resize(msg.value.width, msg.value.height);
            break;
        case "1009":
            ExportImage();
            break;
        case "tips":
            figma.notify(msg.value);
            break;
    }
};
function SetCtypeAndActionTag(obj) {
    if (figma.currentPage.selection[0] == null) {
        return;
    }
    var array = GetAllKeys(obj);
    for (var temp of array) {
        figma.currentPage.selection[0].setSharedPluginData("csd", temp, obj[temp].toString());
    }
    postMessage("1006", GetSharedPluginData(figma.currentPage.selection[0], "ctype"));
}
function SetImagData(obj) {
    var array = GetAllKeys(obj);
    for (var temp of array) {
        var value;
        var name;
        name = obj[temp].name;
        if (obj[temp].value.toString().split(",")[0] == "data:image/png;base64") {
            var image = figma.createImage(figma.base64Decode(obj[temp].value.toString().split(",")[1]));
            value = image.hash;
        }
        else {
            value = obj[temp].value;
        }
        if (file == null || GetImagePath(value, name) == null) {
            figma.currentPage.selection[0].setSharedPluginData("csd", temp, "Default/ImageFile.png");
        }
        else {
            figma.currentPage.selection[0].setSharedPluginData("csd", temp, GetImagePath(value, name));
        }
    }
}
function GetAllFrame() {
    let name_array = new Array();
    let count = 0;
    let fram_array = figma.currentPage.findAllWithCriteria({ types: ["GROUP", "FRAME", "INSTANCE"] });
    for (var node of fram_array) {
        var nodeInfo = {
            id: node.id,
            name: node.name
        };
        name_array[count] = nodeInfo;
        count += 1;
    }
    return name_array;
}
function FrameNameCheck(new_array, curren_frame_array) {
    for (var node of new_array) {
        var node_index = new_array.indexOf(node);
        var compare_node = curren_frame_array[node_index];
        if (compare_node == null || compare_node.name != node.name) {
            return false;
        }
    }
    return true;
}
function SendAllFrame() {
    let now_array = GetAllFrame();
    if (now_array.length != curren_frame_count || FrameNameCheck(now_array, curren_frame_array) == false) {
        postMessage("1001", now_array);
        curren_frame_array = now_array;
        curren_frame_count = now_array.length;
    }
}
function SendAllImage(Node) {
    return __awaiter(this, void 0, void 0, function* () {
        if (Node == null || Node.locked == true) {
            return;
        }
        if ("fills" in Node) {
            for (let patin of Node.fills) {
                if (patin.type == "IMAGE") {
                    let image = figma.getImageByHash(patin.imageHash);
                    let byte = figma.base64Encode(yield image.getBytesAsync());
                    var value = {
                        img_has: patin.imageHash,
                        base64: "data:image/png;base64," + byte
                    };
                    postMessage("1002", value);
                }
            }
        }
        if ("children" in Node) {
            if (Node.children.length > 0) {
                for (let child_node of Node.children) {
                    SendAllImage(child_node);
                }
            }
        }
    });
}
function GetAllKeys(obj) {
    var keys_array = Object.keys(obj);
    return keys_array;
}
function GetChild(Node) {
    var child_value = "";
    if ("children" in Node) {
        var children = Node.children;
        if (children.length > 0) {
            child_value = "<Children>\n";
            for (var i = 0; i < children.length; i++) {
                if (GetNodeProprty(children[i]) != undefined && children[i].locked == false) {
                    child_value += GetNodeProprty(children[i]);
                }
            }
            child_value += "\n</Children>";
        }
    }
    if (child_value == "<Children>\n" + "\n</Children>") {
        child_value = "";
    }
    return child_value;
}
function GetNodeProprty(Node) {
    var ctype = GetSharedPluginData(Node, "ctype");
    tag += 1;
    switch (ctype) {
        case "PanelObjectData":
            return CreatCsdNode(new PanelObjectData(Node));
        case "ListViewObjectData":
            return CreatCsdNode(new ListViewObjectData(Node));
        case "PageViewObjectData":
            return CreatCsdNode(new PageViewObjectData(Node));
        case "ScrollViewObjectData":
            return CreatCsdNode(new ScrollViewObjectData(Node));
        case "ImageViewObjectData":
            return CreatCsdNode(new ImageViewObjectData(Node));
        case "ButtonObjectData":
            return CreatCsdNode(new ButtonObjectData(Node));
        case "LoadingBarObjectData":
            return CreatCsdNode(new LoadingBarObjectData(Node));
        case "SliderObjectData":
            return CreatCsdNode(new SliderObjectData(Node));
        case "TextObjectData":
            return CreatCsdNode(new TextObjectData(Node));
        case "CheckBoxObjectData":
            return CreatCsdNode(new CheckBoxObjectData(Node));
        case "":
    }
}
var BaseInfo = function (node) {
    this.head =
        {};
    this.body = {};
    var parent_size_width = Number(GetSharedPluginData(node.parent, "width")) > node.parent.width ? Number(GetSharedPluginData(node.parent, "width")) : node.parent.width;
    var parent_size_height = Number(GetSharedPluginData(node.parent, "height")) > node.parent.height ? Number(GetSharedPluginData(node.parent, "height")) : node.parent.height;
    this.parent = node.parent.name;
    //Tag
    this.head.Tag = 'Tag="' + tag + '"';
    //Name
    this.head.Name = 'Name="' + node.name + '"';
    var ctype = "";
    if (GetSharedPluginData(node, "ctype") == "") {
        if (node.type == "TEXT") {
            ctype = "TextObjectData";
        }
        if (node.type == "FRAME" || node.type == "GROUP" || node.type == "COMPONENT" || node.type == "INSTANCE") {
            ctype = "PanelObjectData";
        }
    }
    else {
        ctype = GetSharedPluginData(node, "ctype");
    }
    //ctype
    this.head.ctype = 'ctype="' + ctype + '"';
    //actiontag
    if (GetSharedPluginData(node, "ActionTag") == "") {
        this.head.AnctionTag = 'ActionTag="' + GetActionTag(9) + '"';
    }
    else {
        this.head.AnctionTag = 'ActionTag="' + GetSharedPluginData(node, "ActionTag") + '"';
    }
    if (node.visible == false) {
        this.head.Visible = 'Visible="False"';
    }
    //size
    var size_value = new Vector2(node.width, node.height);
    ;
    this.inner_size = new Vector2(0, 0);
    if ("children" in node) {
        if (node.children.length > 0) {
            var last_node = node.children[0];
            var last_node_x = last_node.x + last_node.width;
            var last_node_y = last_node.y + last_node.height;
            for (var i = 0; i < node.children.length; i++) {
                var curren_x = node.children[i].x + node.children[i].width;
                var curren_y = node.children[i].y + node.children[i].height;
                if (last_node_x < curren_x) {
                    this.inner_size.x = curren_x;
                }
                if (last_node_y < curren_y) {
                    this.inner_size.y = curren_y;
                }
            }
        }
    }
    this.body.Size = '<Size X="' + size_value.x.toFixed(4) + '" Y="' + size_value.y.toFixed(4) + '" />';
    SetSharedPluginData(node, "width", this.inner_size.x.toString());
    SetSharedPluginData(node, "height", this.inner_size.y.toString());
    //Children need do
    if ("children" in node) {
        if (node.children.length > 0) {
            this.body.Children = GetChild(node);
        }
    }
    //anchorpoint
    var anchorpoint_value = {
        x: "",
        y: ""
    };
    anchorpoint_value = GetAnchorPoint(GetSharedPluginData(node, "AnchorPoint"));
    this.body.AnchorPoint = '<AnchorPoint ScaleX="' + anchorpoint_value.x + '" ScaleY="' + anchorpoint_value.y + '" />';
    if (node.rotation > 0) {
        this.head.RotationSkewX = 'RotationSkewX="' + (360 - node.rotation).toFixed(4) + '"';
        this.head.RotationSkewY = 'RotationSkewY="' + (360 - node.rotation).toFixed(4) + '"';
    }
    //positon
    var x = 0;
    var y = 0;
    x = ChangPosition(node).x;
    y = ChangPosition(node).y;
    //Filp
    var filp_x = Number(node.absoluteTransform[0][0]);
    var filp_y = Number(node.absoluteTransform[1][1]);
    if (filp_x < 0) {
        this.head.Filpx = 'FlipX="True"';
        x += filp_x * node.width;
    }
    if (filp_y < 0) {
        this.head.Filpx = 'FlipY="True"';
        y -= filp_y * node.height;
    }
    if (node.rotation != 0) {
        this.head.rotation = 'RotationSkewX="' + (node.rotation * -1).toFixed(4) + '" RotationSkewY="' + (node.rotation * -1).toFixed(4) + '"';
    }
    this.body.Position = '<Position X="' + x.toFixed(4) + '" Y="' + y.toFixed(4) + '" />';
    //pre_size
    var pre_size_x = (size_value.x / parent_size_width).toFixed(4);
    var pre_size_y = (size_value.y / parent_size_height).toFixed(4);
    this.body.PreSize = '<PreSize X="' + pre_size_x + '" Y="' + pre_size_y + '" />';
    //pre_position
    var pre_position_x = x / parent_size_width;
    var pre_position_y = y / parent_size_height;
    this.body.PrePosition = '<PrePosition X="' + pre_position_x.toFixed(4) + '" Y="' + pre_position_y.toFixed(4) + '" />';
    //ccolor
    this.body.CColor = '<SingleColor A="' + 255 + '" R="' + 255 + '" G="' + 255 + '" B="' + 255 + '" />';
    //Marigin
    this.head.BottomMargin = 'BottomMargin="' + y.toFixed(4) + '"';
    this.head.RightMargin = 'RightMargin="' + x.toFixed(4) + '"';
    this.head.LeftMargin = 'LeftMargin="' + (node.parent.width - (x + node.width)).toFixed(4) + '"';
    this.head.TopMargin = 'TopMargin="' + (node.parent.height - (y + node.height)).toFixed(4) + '"';
    this.head.TouchEnable = "";
    //IconVisible
    this.head.IconVisible = 'IconVisible="False"';
    this.body.Scale = '<Scale ScaleX="1.0000" ScaleY="1.0000" />';
    this.head.RotationSkewX = "";
    this.head.RotationSkewY = "";
};
var PanelObjectData = function (node) {
    this.baseInfo = new BaseInfo(node);
    // if(this.baseInfo.ctype=="")
    // {
    //   this.baseInfo.head.ctype='ctype="PanelObjectData"'
    //   this.baseInfo.body='<AnchorPoint ScaleX="0.0000" ScaleY="0.0000"/>'
    // }
    this.fill =
        {
            color: new Vector4(1, 1, 1, 1),
            opacity: 1
        };
    if ("fills" in node) {
        if (node.type != "GROUP" && node.fills.length > 0) {
            if (node.fills[0].type == "SOLID") {
                this.fill = node.fills[0];
            }
        }
    }
    //BackColorAlpha
    var backalpha = 102;
    backalpha = this.fill.opacity * 255;
    this.baseInfo.head.BackColorAlpha = 'BackColorAlpha="' + backalpha.toFixed(0) + '"';
    //ClipAble
    if ("clipsContent" in node) {
        this.baseInfo.head.ClipAble = 'ClipAble="' + node.clipsContent + '"';
    }
    else {
        this.baseInfo.head.ClipAble = '';
    }
    //ComboBoxIndex
    var comboBoxIndex = "";
    if (this.fill.type == "SOLID" && this.fill.visable == true) {
        comboBoxIndex = 'ComboBoxIndex="' + 1 + '"';
    }
    this.baseInfo.head.ComboBoxIndex = comboBoxIndex;
    //SingleColor
    this.baseInfo.body.SingleColor = '<SingleColor A="' + 255 + '" R="' + (this.fill.color.r * 255).toFixed(0) + '" G="' + (this.fill.color.g * 255).toFixed(0) + '" B="' + (this.fill.color.b * 255).toFixed(0) + '" />';
    this.baseInfo.body.FirstColor = '<FirstColor A="' + 255 + '" R="' + (this.fill.color.r * 255).toFixed(0) + '" G="' + (this.fill.color.g * 255).toFixed(0) + '" B="' + (this.fill.color.b * 255).toFixed(0) + '" />';
    this.baseInfo.body.EndColor = '<EndColor A="' + 255 + '" R="' + 255 + '" G="' + 255 + '" B="' + 255 + '" />';
    this.baseInfo.body.ColorVector = '<ColorVector ScaleY="1.0000" />';
    this.baseInfo.head.Scale9Height = 'Scale9Height="' + 1 + '"';
    this.baseInfo.head.Scale9Width = 'Scale9Width="' + 1 + '"';
    //ColorAngel
    this.baseInfo.head.ColorAngle = 'ColorAngle="90.0000"';
};
var ListViewObjectData = function (node) {
    this.baseInfo = new PanelObjectData(node).baseInfo;
    //滚动方向
    this.baseInfo.head.DirectionType = "";
    this.baseInfo.head.ScrollDirectionType = 'ScrollDirectionType="0"';
    this.baseInfo.head.LayoutType = 'LayoutType="2"';
    if (this.baseInfo.inner_size.y + this.baseInfo.inner_size.width > node.height) {
        this.baseInfo.head.DirectionType = 'DirectionType="Vertical"';
        this.baseInfo.head.LayoutType = 'LayoutType="1"';
    }
    if ("layoutMode" in node) {
        if (node.layoutMode == "VERTICAL") {
            this.baseInfo.head.DirectionType = 'DirectionType="Vertical"';
            this.baseInfo.head.LayoutType = 'LayoutType="1"';
        }
    }
    //子控件间距
    this.baseInfo.head.ItemMargin = "";
    if ("layoutMode" in node) {
        this.baseInfo.head.ItemMargin = 'ItemMargin="' + node.itemSpacing + '"';
    }
    else {
        var item_space;
        if (node.layoutMode == "VERTICAL") {
            item_space = node.children[1].y - (node.children[0].y + node.children[0].height);
        }
        else {
            item_space = node.children[1].x - (node.children[0].x + node.children[0].width);
        }
        this.baseInfo.head.ItemMargin = 'ItemMargin="' + item_space + '"';
    }
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
    //console.warn(this.baseInfo);
};
var PageViewObjectData = function (Node) {
    var Frame = figma.createFrame();
    Frame.x = Node.x;
    Frame.y = Node.y;
    Frame.resize(Node.width, Node.height);
    Frame.name = Node.name;
    Node.parent.appendChild(Frame);
    SetSharedPluginData(Frame, "ctype", "PageViewObjectData");
    SetSharedPluginData(Frame, "ActionTag", GetActionTag(9));
    SetSharedPluginData(Frame, "AnchorPoint", "0.0000,0.0000");
    SetSharedPluginData(Node, "ctype", "PanelObjectData");
    SetSharedPluginData(Frame, "ActionTag", GetActionTag(9));
    Node.x = Node.x - Frame.x;
    Node.y = Node.y - Frame.y;
    Frame.appendChild(Node);
    this.baseInfo = new ListViewObjectData(Frame).baseInfo;
    this.baseInfo.head.ItemMargin = "";
    this.baseInfo.head.DirectionType = "";
    this.baseInfo.head.LayoutType = 'LayoutType="2"';
};
var ScrollViewObjectData = function (Node) {
    this.baseInfo = new ListViewObjectData(Node).baseInfo;
    this.baseInfo.head.LayoutType = '';
    this.baseInfo.head.ScrollDirectionType = 'ScrollDirectionType="Vertical"';
    if (this.baseInfo.inner_size.x > Node.width) {
        this.baseInfo.head.ScrollDirectionType = 'ScrollDirectionType="Horizontal"';
    }
    if (this.baseInfo.inner_size.y > Node.height && this.baseInfo.inner_size.x > Node.width) {
        this.baseInfo.head.ScrollDirectionType = 'ScrollDirectionType="Vertical_Horizontal"';
    }
    var inner_x = this.baseInfo.inner_size.x > Node.width ? this.baseInfo.inner_size.x : Node.width;
    var inner_y = this.baseInfo.inner_size.y > Node.height ? this.baseInfo.inner_size.y : Node.height;
    this.baseInfo.body.InnerNodeSize = '<InnerNodeSize Width="' + inner_x + '" Height="' + inner_y + '" />';
};
var ImageViewObjectData = function (Node) {
    this.baseInfo = new BaseInfo(Node);
    if (Node.opacity < 1) {
        this.baseInfo.head.Alpha = 'Alpha="' + (Node.opacity * 255).toFixed(0) + '"';
    }
    else {
        if ("fills" in Node && Node.fills.length > 0) {
            this.baseInfo.head.Alpha = 'Alpha="' + (Node.fills[0].opacity * 255).toFixed(0) + '"';
        }
    }
    if ("fills" in Node && Node.fills.length > 0) {
        if (Node.fills[0].type == "SOLID") {
            var color = Node.fills[0].color;
            this.baseInfo.body.CColor = '<CColor A="255" R="' + (color.r * 255).toFixed(0) + '" G="' + (color.g * 255).toFixed(0) + '" B="' + (color.b * 255).toFixed(0) + '" />';
        }
    }
    this.baseInfo.body.path = '<FileData Type="Default" Path="Default/ImageFile.png" Plist="" />';
    if (GetSharedPluginData(Node, "FileData") != "") {
        this.baseInfo.body.path = '<FileData Type="Normal" Path="' + GetSharedPluginData(Node, "FileData") + '" Plist="" />';
    }
};
var LoadingBarObjectData = function (Node) {
    this.baseInfo = new ImageViewObjectData(Node).baseInfo;
    this.baseInfo.body.path = '<ImageFileData Type="Default" Path="Default/ImageFile.png" Plist="" />';
    if (GetSharedPluginData(Node, "FileData") != "") {
        this.baseInfo.body.path = '<ImageFileData Type="Normal" Path="' + GetSharedPluginData(Node, "ImageFileData") + '" Plist="" />';
    }
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
};
var ButtonObjectData = function (Node) {
    this.baseInfo = new BaseInfo(Node);
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
    this.baseInfo.head.FontSiz = 'FontSize="14"';
    var BottomEage = 14;
    var LeftEage = 15;
    var RightEage = 15;
    var TopEage = 14;
    var Scale9Width = Node.width - (RightEage + LeftEage);
    var Scale9Height = Node.width - (BottomEage + TopEage);
    var Scale9OriginX = LeftEage;
    var Scale9OriginY = BottomEage;
    this.baseInfo.head.Scale9Width = 'Scale9Width="' + Scale9Width + '"';
    this.baseInfo.head.Scale9Height = 'Scale9Height="' + Scale9Height + '"';
    this.baseInfo.head.Scale9OriginX = 'Scale9OriginX="' + Scale9OriginX + '"';
    this.baseInfo.head.Scale9OriginY = 'Scale9OriginY="' + Scale9OriginY + '"';
    this.baseInfo.head.BottomEage = 'BottomEage="' + BottomEage + '"';
    this.baseInfo.head.LeftEage = 'LeftEage="' + LeftEage + '"';
    this.baseInfo.head.RightEage = 'RightEage="' + RightEage + '"';
    this.baseInfo.head.TopEage = 'TopEage="' + TopEage + '"';
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
    this.baseInfo.head.ShadowOffsetX = 'ShadowOffsetX="2.0000"';
    this.baseInfo.head.ShadowOffsetY = 'ShadowOffsetY="2.0000"';
    this.baseInfo.body.TextColor = '<TextColor A="255" R="65" G="65" B="70" />';
    this.baseInfo.body.DisabledFileData = '<DisabledFileData Type="Default" Path="Default/Button_Disable.png" Plist="" />';
    this.baseInfo.body.PressedFileData = '<PressedFileData Type="Default" Path="Default/Button_Press.png" Plist="" />';
    this.baseInfo.body.NormalFileData = '<NormalFileData Type="Default" Path="Default/Button_Normal.png" Plist="" />';
    if (GetSharedPluginData(Node, "DisabledFileData") != "") {
        this.baseInfo.body.DisabledFileData = '<DisabledFileData Type="Normal" Path="' + GetSharedPluginData(Node, "DisabledFileData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "PressedFileData") != "") {
        this.baseInfo.body.PressedFileData = '<PressedFileData Type="Normal" Path="' + GetSharedPluginData(Node, "PressedFileData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "NormalFileData") != "") {
        this.baseInfo.body.NormalFileData = '<NormalFileData Type="Normal" Path="' + GetSharedPluginData(Node, "NormalFileData") + '" Plist="" />';
    }
};
var SliderObjectData = function (Node) {
    this.baseInfo = new BaseInfo(Node);
    this.baseInfo.head.TouchEnable = 'TouchEnable="True"';
    this.baseInfo.head.PercentInfo = 'PercentInfo="50"';
    this.baseInfo.body.BackGroundData = '<BackGroundData Type="Default" Path="Default/Slider_Back.png" Plist="" />';
    this.baseInfo.body.ProgressBarData = '<ProgressBarData Type="Default" Path="Default/Slider_PressBar.png" Plist="" />';
    this.baseInfo.body.BallNormalData = '<BallNormalData Type="Default" Path="Default/SliderNode_Normal.png" Plist="" />';
    if (GetSharedPluginData(Node, "BackGroundData") != "") {
        this.baseInfo.body.BackGroundData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "BackGroundData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "ProgressBarData") != "") {
        this.baseInfo.body.ProgressBarData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "ProgressBarData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "BallNormalData") != "") {
        this.baseInfo.body.BallNormalData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "BallNormalData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "BallPressedData") != "") {
        this.baseInfo.body.BallPressedData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "BallPressedData") + '" Plist="" />';
    }
    if (GetSharedPluginData(Node, "BallDisabledData") != "") {
        this.baseInfo.body.BallDisabledData = '<BackGroundData Type="Normal" Path="' + GetSharedPluginData(Node, "BallDisabledData") + '" Plist="" />';
    }
};
var TextObjectData = function (Node) {
    if (Node.type != "TEXT") {
        return;
    }
    ;
    figma.loadFontAsync(Node.fontName);
    this.baseInfo = new BaseInfo(Node);
    this.baseInfo.head.FontSize = 'FontSize="' + Node.fontSize + '"';
    this.baseInfo.head.AdditionalKerning = 'AdditionalKerning="' + Node.letterSpacing.value + '"';
    this.baseInfo.head.LabelText = 'LabelText="' + Node.characters + '"';
    //check is counster size
    // if(Node.width>test.width||Node.height>test.height)
    // {
    //   this.baseInfo.head.IsCustomSize='IsCustomSize="True"'
    // }
    if (file == null || GetFontPath(Node.fontName.family) == null) {
        this.baseInfo.body.FontResource = '<FontResource Type="Normal" Path="fonts/FZLBJW.ttf" Plist="" />';
    }
    else {
        this.baseInfo.body.FontResource = '<FontResource Type="Normal" Path="' + GetFontPath(Node.fontName.family) + '" Plist="" />';
    }
    if (Node.lineHeight.value != undefined) {
        this.baseInfo.head.LineSpacing = 'LineSpacing="' + Node.lineHeight.value + '"';
    }
    this.baseInfo.body.OutlineColor = '<OutlineColor A="255" R="255" G="0" B="0" />';
    this.baseInfo.head.ShadowOffsetX = 'ShadowOffsetX="2.0000"';
    this.baseInfo.head.ShadowOffsetY = 'ShadowOffsetY="2.0000"';
    if ("strokes" in Node && Node.strokes.length > 0) {
        var color = Node.strokes[0].color;
        this.baseInfo.head.OutlineEnabled = 'OutlineEnabled="True"';
        this.baseInfo.body.OutlineColor = '<OutlineColor A="255" R="' + (color.r * 255).toFixed(0) + '" G="' + (color.g * 255).toFixed(0) + '" B="' + (color.b * 255).toFixed(0) + '" />';
        this.baseInfo.head.OutlineSize = 'OutlineSize="' + Node.strokeWeight + '"';
    }
    if ("effects" in Node && Node.effects.length > 0) {
        var color = Node.effects[0].color;
        this.baseInfo.head.ShadowEnabled = 'ShadowEnabled="True"';
        this.baseInfo.body.ShadowColor = '<ShadowColor A="' + (color.a * 255).toFixed(0) + '" R="' + (color.r * 255).toFixed(0) + '" G="' + (color.g * 255).toFixed(0) + '" B="' + (color.b * 255).toFixed(0) + '" />';
        this.baseInfo.head.ShadowOffsetX = 'ShadowOffsetX="' + (Node.effects[0].offset.x).toFixed(4) + '"';
        this.baseInfo.head.ShadowOffsetY = 'ShadowOffsetY="' + (-Node.effects[0].offset.y).toFixed(4) + '"';
    }
    if ("fills" in Node && Node.fills.length > 0) {
        var color;
        if (Node.fills[0].type == "SOLID") {
            color = Node.fills[0].color;
        }
        else if (Node.fills[0].type == "GRADIENT_LINEAR") {
            color = Node.fills[0].gradientStops[2].color;
        }
        this.baseInfo.body.CColor = '<CColor A="255" R="' + (color.r * 255).toFixed(0) + '" G="' + (color.g * 255).toFixed(0) + '" B="' + (color.b * 255).toFixed(0) + '" />';
    }
};
function CheckBoxObjectData(Node) {
    this.baseInfo = new BaseInfo(Node);
    this.baseInfo.body.NormalBackFileData = '<NormalBackFileData Type="Normal" Path="' + GetSharedPluginData(Node, "NormalBackFileData") + '" Plist="" />';
    this.baseInfo.body.PressedBackFileData = '<PressedBackFileData Type="Normal" Path="' + GetSharedPluginData(Node, "PressedBackFileData") + '" Plist="" />';
    this.baseInfo.body.DisableBackFileData = '<DisableBackFileData Type="Normal" Path="' + GetSharedPluginData(Node, "DisableBackFileData") + '" Plist="" />';
    this.baseInfo.body.NodeNormalFileData = '<NodeNormalFileData Type="Normal" Path="' + GetSharedPluginData(Node, "NodeNormalFileData") + '" Plist="" />';
    this.baseInfo.body.NodeDisableFileData = '<NodeDisableFileData Type="Normal" Path="' + GetSharedPluginData(Node, "NodeDisableFileData") + '" Plist="" />';
}
function GetAnchorPoint(value) {
    var x = value.split(',')[0];
    var y = value.split(',')[0];
    var anchorPoint = new Vector2(x, y);
    return anchorPoint;
}
function postMessage(_type, value) {
    var msg = {
        type: _type,
        value: value
    };
    figma.ui.postMessage(msg);
}
function GetSharedPluginData(Node, key) {
    return Node.getSharedPluginData("csd", key);
}
function SetSharedPluginData(Node, key, value) {
    Node.setSharedPluginData("csd", key, value);
}
function ClearSharedPlugingData(Node) {
    var keys = Node.getSharedPluginDataKeys("csd");
    for (var key of keys) {
        Node.setSharedPluginData("csd", key, "");
    }
    postMessage("1006", GetSharedPluginData(Node, "ctype"));
}
function CreatCsdNode(info) {
    var head_keys = Object.keys(info.baseInfo.head);
    var content = '<AbstractNodeData';
    for (var key in head_keys) {
        content += ' ' + info.baseInfo.head[head_keys[key]];
    }
    content += '>';
    var body_keys = Object.keys(info.baseInfo.body);
    for (var key in body_keys) {
        content += '\n' + info.baseInfo.body[body_keys[key]];
    }
    content += '\n</AbstractNodeData>\n';
    return content;
}
function GetActionTag(count) {
    var action_tag = "";
    for (let index = 0; index < count; index++) {
        action_tag += Math.floor(Math.random() * 10);
    }
    return action_tag;
}
function ChangPosition(Node) {
    var anchorpoint_value = {
        x: "",
        y: ""
    };
    var anchorpoint_value = {
        x: "",
        y: ""
    };
    if (GetSharedPluginData(Node, "AnchorPoint") == "") {
        if (Node.type == "TEXT") {
            anchorpoint_value.x = "0.5000";
            anchorpoint_value.y = "0.5000";
        }
        if (Node.type == "FRAME" || Node.type == "GROUP" || Node.type == "COMPONENT" || Node.type == "INSTANCE") {
            anchorpoint_value.x = "0.0000";
            anchorpoint_value.y = "0.0000";
        }
    }
    else {
        anchorpoint_value = GetAnchorPoint(GetSharedPluginData(Node, "AnchorPoint"));
    }
    var parent = Node.parent;
    var x = 0;
    var y = 0;
    var width = Number(Node.width) * Number(anchorpoint_value.x);
    var height = Number(Node.height) * Number(anchorpoint_value.y);
    var distanc = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2));
    var angle = (Node.rotation / (180 / Math.PI)) + Math.atan2(height, width);
    var x_offset = Number((distanc * Math.sin(angle)).toFixed(4));
    var y_offset = Number((distanc * Math.cos(angle)).toFixed(4));
    //var distance = 
    switch (parent.type) {
        case "FRAME":
            x = Node.rotation != 0 ? Node.x + x_offset : Node.x + (Node.width * (Number(anchorpoint_value.x)));
            y = Node.rotation != 0 ? parent.height - (Node.y + y_offset) : parent.height - (Node.y + (Node.height * (1 - (Number(anchorpoint_value.y)))));
            break;
        case "GROUP":
            x = (Node.x + (Node.width * (Number(anchorpoint_value.x)))) - parent.x;
            y = (parent.y + parent.height) - (Node.y + (Node.height * (1 - Number(anchorpoint_value.y))));
            break;
        case "COMPONENT":
        case "INSTANCE":
            x = Node.x + (Node.width * (Number(anchorpoint_value.x)));
            y = parent.height - (Node.y + (Node.height * ((1 - Number(anchorpoint_value.y)))));
            break;
    }
    return new Vector2(x, y);
}
function GetImagePath(img_has, name) {
    for (var key in file["img_res"]) {
        if (name == null) {
            if (file["img_res"][key] == img_has) {
                return key;
            }
        }
        else {
            if (file["img_res"][key] == img_has && key.substring(key.lastIndexOf('/') + 1) == name) {
                return key;
            }
        }
    }
    return null;
}
function GetFontPath(family) {
    for (var key in file["font_res"]) {
        var count = 0;
        for (var value of family) {
            if (key.indexOf(value) != -1) {
                count++;
            }
        }
        if ((count / family.length > 0.8)) {
            return file["font_res"][key];
        }
    }
    return null;
}
function ExportImage() {
    return __awaiter(this, void 0, void 0, function* () {
        var img_array = new Array();
        for (var img_data of figma.currentPage.selection) {
            if ("fills" in img_data) {
                if (img_data.fills[0].type == "IMAGE") {
                    let image = figma.getImageByHash(img_data.fills[0].imageHash);
                    let byte = figma.base64Encode(yield image.getBytesAsync());
                    var imgage = {
                        name: img_data.name,
                        img_data: byte,
                    };
                    img_array.push(imgage);
                }
            }
            postMessage("1009", img_array);
        }
    });
}
