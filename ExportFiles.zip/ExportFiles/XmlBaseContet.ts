var XmlBaseContet=function(node_info)
{
    
}